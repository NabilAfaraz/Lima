import re
from urlparse import urlparse


f = input("Please enter the name of the local .html file ")
u = input("Please enter the URL, from this file was downloaded!")

f1=open(f, "r")

def download_ALL(file, url):
    m = file.read()
    o= urlparse(url)
    host = o.netloc
    protocol = o.scheme
    link = r'<img[^>]*\ssrc="(.*?)"'
    imgs = re.findall(link, str(m))

    i=0
    while(i<len(imgs)):
        img = imgs[i]
        if(img.find(protocol + "://" +host)==-1):
            img=protocol + "://"+ host + imgs[i]
        print(img)
        wget.download(img)
        i=i+1

download_ALL(f1, u)
