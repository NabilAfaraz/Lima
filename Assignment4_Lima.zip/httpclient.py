print 'Group Lima'
print 'Members : Nabil Bukhari, Nizam & Goggi'
print '\n'

from socket import *
from urlparse import urlparse
import sys
import time
import re

urladdress=input("Please Enter Url:")
parsedUrl = urlparse(urladdress)

myhost=parsedUrl.netloc
mypath=parsedUrl.path
port = 80  # web


#now connect to the web server on port 80
# - the normal http port
#s.connect(("www.mcmillan-inc.com", 80))

print('# Creating socket')
try:
    #create an INET, STREAMing socket
    s = socket(AF_INET, SOCK_STREAM)
    print('#Socket Created')
except error as s_err:
    print('Failed to create socket')
    sys.exit()

print('# Connecting to web server')
try:
    #now connect to the web server on port 80
    # - the normal http port
    s.connect((myhost, 80))
    print('#Connected')
except conerror :
    print('Failed to Connect')
    sys.exit()

# Send data to remote server
print('# Sending data to server')
request = "GET "+ mypath +" HTTP/1.0\r\n\r\n"

try:
    s.sendall(request.encode('utf'))
except socket.error:
    print
    'Send failed'
    sys.exit()

# Receive data
print('# Receive data from server')


def recv_timeout(the_socket, timeout=2):
    # make socket non blocking
    the_socket.setblocking(0)
    total_data = [];
    podatoci=""
    data = '';
    # beginning time
    begin = time.time()
    while 1:
        #Connection will break after timeout while data is recieved
        if total_data and time.time() - begin > timeout:
            break

        # While no data is received, wait for twice the timeout and then dc
        elif time.time() - begin > timeout * 2:
            break

        # recv something
        try:

            data = the_socket.recv(9000)
            if data:
                total_data.append(data)
                podatoci = podatoci + data.decode()
                # change the beginning time for measurement
                begin = time.time()
            else:
                # sleep for sometime to indicate a gap
                time.sleep(0.1)
        except:
            pass
    if(podatoci.find("200 OK") != -1):
        temp = sys.stdout  # store original stdout object for later
        sys.stdout = open('header.txt', 'w')  # redirect all prints to this log file
        print(podatoci)
        sys.stdout.close()  # ordinary file object
        sys.stdout = temp  # restore print commands to interactive prompt
        seperate(podatoci)
    else:
        print("----------------------------------")
        #print(total_data)
        #Inserting data in a text file
        text_file = open("Output.html", "w")
        text_file.write("Val: %s" % total_data)
        text_file.close()
        
    # join all parts to make final string
    return "".join(str(total_data)) 


def seperate(list_to_Separate):
    aaa = str(list_to_Separate).split('\r\n\r\n')
    print(aaa[0])
    iphph = open("index.php.header", "w")
    iphp = open("index.php", "w")
    iphph.write(aaa[0])
    iphp.write(aaa[1])
    iphph.close()
    iphp.close()
    return 0

recv_timeout(s)

s.close()
print ("\nPlease Check Output File")
